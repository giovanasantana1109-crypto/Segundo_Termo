//Parte B - Prática

//const numero1 = 20;
//const numero2 = 5;
//const soma = numero1 + numero2;
//const subtracao = numero1 - numero2;
//const multiplicacao = numero1 * numero2;
//const divisao = numero1 / numero2;
//const resto = numero1 % numero2;
//console.log("Soma:", soma);
//console.log("Subtração:", subtracao);
//console.log("Multiplicação:", multiplicacao);
//console.log("Divisão:", divisao);
//console.log("Resto da divisão:", resto);


//Desafio 1 - Calcular uma média

// const soma = 10 + 5;
// const subtracao = 10 - 5;
// const multiplicacao = 5 * 2;
// const divisao = 10 / 2;
// const resto = 10 % 5;
// console.log("Soma:", soma);
// console.log("Subtração:", subtracao);
// console.log("Multiplicação:", multiplicacao);
// console.log("Divisão:", divisao);
// console.log("Resto da divisão:", resto);

//Desafio 1 - Calcular uma média

// const nota1 = 7;
// const nota2 = 8;
// const nota3 = 9;
// const media = (nota1 + nota2 + nota3) / 3;
// console.log("Média:", media);

//Desafio 2 - Calcular uma compra

// const produto = "Caderno";
// const preco = 30;
// const quantidade = 5;
// const total = preco * quantidade;
// console.log("Produto:", produto);
// console.log("Valor total:", total);